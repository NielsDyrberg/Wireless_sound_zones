// SPDX-License-Identifier: GPL-2.0-only
#include "../../../../lib/fdt.c"
