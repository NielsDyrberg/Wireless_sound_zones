// SPDX-License-Identifier: GPL-2.0-only
#include "../../../../lib/fdt_ro.c"
